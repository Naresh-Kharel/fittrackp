// server/routes/data.js
import express from 'express'
import auth from '../../server/middleware/auth.js'
import Profile from '../../server/models/FitnessProfile.js'

const router = express.Router()

// CREATE profile
router.post('/user-data', auth, async (req, res) => {
  const { height, weight, workoutStyle, goalWeight } = req.body
  const bmi = weight / ((height / 100) ** 2)
  const profile = await Profile.create({
    user: req.userId,
    height,
    weight,
    workoutStyle,
    goalWeight,
    currentBMI: bmi
  })
  res.json(profile)
})

// READ BMI & plan
router.get('/bmi/:id', auth, async (req, res) => {
  const profile = await Profile.findById(req.params.id)
  if (!profile || profile.user.toString() !== req.userId)
    return res.status(404).json({ error: 'Not found' })

  res.json({ bmi: profile.currentBMI, plan: {} }) // placeholder
})

// DELETE profile
router.delete('/user/:id', auth, async (req, res) => {
  await Profile.findOneAndDelete({ _id: req.params.id, user: req.userId })
  res.json({ message: 'Profile deleted' })
})

export default router
