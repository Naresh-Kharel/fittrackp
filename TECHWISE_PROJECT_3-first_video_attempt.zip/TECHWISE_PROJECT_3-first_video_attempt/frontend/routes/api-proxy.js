// =========================================================================
//  API PROXY ROUTES (routes/api-proxy.js)
// =========================================================================

const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

// Route to generate fitness plan (proxies request to Gemini API)
router.post('/generate-fitness-plan', async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  // API call configuration
  const apiKey = ""; // If you want to use models other than gemini-2.5-flash-preview-05-20 or imagen-3.0-generate-002, provide an API key here. Otherwise, leave this as-is.
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key=${apiKey}`;

  let retries = 0;
  const maxRetries = 3;
  let response;

  while (retries < maxRetries) {
    try {
      const payload = {
        contents: [{
          parts: [{ text: prompt }]
        }]
      };

      response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        break; // Success, exit the loop
      } else if (response.status === 429) {
        // Handle rate limiting with exponential backoff
        const delay = Math.pow(2, retries) * 1000;
        console.warn(`Rate limit exceeded. Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        retries++;
      } else {
        // Other HTTP errors
        console.error(`API returned non-OK status: ${response.status}`);
        const errorText = await response.text();
        return res.status(response.status).json({ error: errorText });
      }
    } catch (error) {
      console.error('Fetch error:', error);
      retries++;
    }
  }

  if (!response || !response.ok) {
    return res.status(500).json({ error: 'Failed to generate fitness plan after multiple retries.' });
  }

  try {
    const result = await response.json();
    const fitnessPlan = result.candidates[0].content.parts[0].text;
    res.status(200).json({ plan: fitnessPlan });
  } catch (error) {
    console.error('Error parsing JSON from API:', error);
    res.status(500).json({ error: 'An unexpected error occurred while processing the API response.' });
  }
});

module.exports = router;
