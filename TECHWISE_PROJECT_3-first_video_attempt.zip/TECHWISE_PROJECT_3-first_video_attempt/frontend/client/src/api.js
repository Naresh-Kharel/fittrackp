// client/src/api.js
import axios from 'axios';

const API = axios.create({
  baseURL: 'http://127.0.0.1:5001/api',
});

API.interceptors.request.use(cfg => {
  const token = localStorage.getItem('fittrack_jwt_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

export default API;
