// client/src/components/AuthPage.jsx
import React, { useState, useEffect, useContext } from 'react';

import API from '../api';

export default function AuthPage({ type, setUserData, showCustomModal }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isRegister, setIsRegister] = useState(type === 'register');
  const { setCurrentPath } = useContext(RouterContext);

  useEffect(() => {
    setIsRegister(type === 'register');
  }, [type]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Validate password match on register
    if (isRegister && password !== confirmPassword) {
      showCustomModal('Passwords do not match!');
      return;
    }

    try {
      const endpoint = isRegister ? '/auth/register' : '/auth/login';
      const { data } = await API.post(endpoint, { email, password });

      if (!isRegister) {
        // On login, store JWT and set user
        localStorage.setItem('fittrack_jwt_token', data.token);
        setUserData({ email });
      }

      showCustomModal(data.message || (isRegister ? 'Registration successful!' : 'Login successful!'));
      setCurrentPath(isRegister ? '/login' : '/dashboard');
    } catch (err) {
      showCustomModal(err.response?.data?.error || err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#1A1A1A] p-4">
      <form onSubmit={handleSubmit} className="bg-[#2D2D2D] p-8 rounded-xl shadow-lg space-y-4 w-full max-w-sm">
        <h2 className="text-2xl font-bold text-[#CCFF00] text-center">
          {isRegister ? 'Register' : 'Login'}
        </h2>

        {/* Email Input */}
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          required
          className="w-full p-3 rounded-md bg-[#1A1A1A] text-white focus:outline-none focus:ring-2 focus:ring-[#AFFF00]"
        />

        {/* Password Input */}
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          required
          className="w-full p-3 rounded-md bg-[#1A1A1A] text-white focus:outline-none focus:ring-2 focus:ring-[#AFFF00]"
        />

        {/* Confirm Password on Register */}
        {isRegister && (
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="Confirm Password"
            required
            className="w-full p-3 rounded-md bg-[#1A1A1A] text-white focus:outline-none focus:ring-2 focus:ring-[#AFFF00]"
          />
        )}

        {/* Submit Button */}
        <button
          type="submit"
          className="w-full bg-gradient-to-r from-[#AFFF00] to-[#66CC00] text-[#1A1A1A] font-bold py-3 rounded-full hover:scale-105 transition"
        >
          {isRegister ? 'Sign Up' : 'Log In'}
        </button>

        {/* Toggle Auth Mode */}
        <p className="text-center text-gray-400">
          {isRegister ? 'Already have an account?' : 'Don’t have an account?'}{' '}
          <Link to={isRegister ? '/login' : '/register'} className="text-[#AFFF00]">
            {isRegister ? 'Log In' : 'Register'}
          </Link>
        </p>
      </form>
    </div>
  );
}
