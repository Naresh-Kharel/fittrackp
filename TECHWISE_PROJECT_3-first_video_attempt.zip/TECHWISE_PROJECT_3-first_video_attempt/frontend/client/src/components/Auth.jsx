import { useState } from 'react';
import API from '../api';

export default function Auth({ mode }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const handle = async e => {
    e.preventDefault();
    try {
      const url = mode === 'login' ? '/auth/login' : '/auth/register';
      const { data } = await API.post(url, { email, password });
      if (mode === 'login') {
        localStorage.setItem('fittrack_token', data.token);
        // redirect to profile form or dashboard
      }
      alert(data.message || 'Success');
    } catch (err) {
      alert(err.response?.data?.error || err.message);
    }
  };

  return (
    <form onSubmit={handle}>
      <h2>{mode === 'login' ? 'Login' : 'Register'}</h2>
      <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" required />
      <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" required />
      <button type="submit">{mode === 'login' ? 'Log In' : 'Sign Up'}</button>
    </form>
  );
}
