import React, { useState, useEffect, useCallback, useContext } from 'react';

// =========================================================================
//  1. CONTEXT SETUP & MAIN APP COMPONENT
// =========================================================================

// Context for managing application-wide state and navigation
const RouterContext = React.createContext({});

// --- Loading Overlay Component ---
const LoadingOverlay = ({ message }) => (
  <div className="fixed inset-0 bg-black bg-opacity-60 flex flex-col items-center justify-center z-50 p-4">
    <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-[#5C8374]"></div>
    <p className="mt-4 text-white text-center text-lg font-semibold">{message}</p>
  </div>
);

// Custom modal to replace alert() and confirm()
const CustomModal = ({ message, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-[#2A2A2A] text-white rounded-lg shadow-lg p-6 max-w-sm w-full text-center">
        <p className="text-lg mb-4">{message}</p>
        <button
          onClick={onClose}
          className="w-full bg-[#5C8374] text-white py-2 rounded-md font-semibold hover:bg-[#4E6C5C] transition-colors"
        >
          Close
        </button>
      </div>
    </div>
  );
};

// --- Navbar Component for logged-in users ---
const Navbar = () => {
  const { setCurrentPath, handleLogout } = useContext(RouterContext);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navigate = (path) => {
    setCurrentPath(path);
    setIsMenuOpen(false);
  };

  return (
    <nav className="bg-[#2A2A2A] text-white shadow-lg sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between">
          <div>
            <a href="#/dashboard" onClick={() => navigate('/dashboard')} className="flex items-center py-4 px-2">
              <span className="font-semibold text-[#5C8374] text-4xl">FitTrack</span>
            </a>
          </div>
          <div className="hidden md:flex items-center space-x-3">
            <a href="#/dashboard" onClick={() => navigate('/dashboard')} className="py-4 px-2 text-gray-300 hover:text-white transition duration-300">Dashboard</a>
            <a href="#/profile" onClick={() => navigate('/profile')} className="py-4 px-2 text-gray-300 hover:text-white transition duration-300">Profile</a>
            <button onClick={handleLogout} className="py-2 px-4 bg-[#5C8374] text-white rounded font-semibold hover:bg-[#4E6C5C] transition-colors">Logout</button>
          </div>
          <div className="md:hidden flex items-center">
            <button className="outline-none mobile-menu-button" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <svg className="w-6 h-6 text-gray-400 hover:text-white" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
                <path d={!isMenuOpen ? "M4 6h16M4 12h16M4 18h16" : "M6 18L18 6M6 6l12 12"}></path>
              </svg>
            </button>
          </div>
        </div>
      </div>
      <div className={`${isMenuOpen ? 'block' : 'hidden'} md:hidden`}>
        <a href="#/dashboard" onClick={() => navigate('/dashboard')} className="block py-4 px-4 text-sm hover:bg-[#5C8374] transition duration-300">Dashboard</a>
        <a href="#/profile" onClick={() => navigate('/profile')} className="block py-4 px-4 text-sm hover:bg-[#5C8374] transition duration-300">Profile</a>
        <button onClick={handleLogout} className="block w-full text-left py-4 px-4 text-sm hover:bg-[#5C8374] transition duration-300">Logout</button>
      </div>
    </nav>
  );
};

// --- Navbar Component for non-logged-in pages ---
const AuthNavbar = () => {
    return (
        <nav className="bg-[#2A2A2A] text-white shadow-lg sticky top-0 z-40">
            <div className="max-w-6xl mx-auto px-4">
                <div className="flex justify-center items-center">
                    <a href="#/" className="flex items-center py-4 px-2">
                        <span className="font-semibold text-[#5C8374] text-4xl">FitTrack</span>
                    </a>
                </div>
            </div>
        </nav>
    );
};

// Main App component that handles routing and state
const App = () => {
  const [currentPath, setCurrentPath] = useState(window.location.hash.slice(1) || '/');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  
  // Application data state
  const [userData, setUserData] = useState(null);
  const [userName, setUserName] = useState(null);
  const [fitnessData, setFitnessData] = useState(null);
  const [bmiResult, setBmiResult] = useState(null);
  const [fitnessPlan, setFitnessPlan] = useState('');

  // Function to show a custom modal
  const showModal = (message) => {
    setModalMessage(message);
    setIsModalOpen(true);
  };

  const handleHashChange = useCallback(() => {
    setCurrentPath(window.location.hash.slice(1) || '/');
  }, []);

  useEffect(() => {
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [handleHashChange]);
  
  useEffect(() => {
    const token = localStorage.getItem('token');
    const name = localStorage.getItem('userName');
    if (token) {
      setUserData({ token });
      setUserName(name);
      if (window.location.hash === '' || window.location.hash === '#/') {
        setCurrentPath('/dashboard');
      }
    }
  }, []);

  const handleLogout = useCallback(() => {
    localStorage.removeItem('token');
    localStorage.removeItem('userName');
    setUserData(null);
    setUserName(null);
    setFitnessData(null);
    setBmiResult(null);
    setFitnessPlan('');
    setCurrentPath('/');
  }, []);

  // --- Components ---
  const Home = () => (
    <div className="min-h-screen bg-[#1A1A1A] text-white flex flex-col items-center justify-center p-4">
      <div className="text-center">
        <h1 className="text-5xl font-bold mb-4">Welcome to FitTrack</h1>
        <p className="text-lg text-gray-400 mb-8">Your personal AI-powered fitness tracker and planner.</p>
        <div className="space-x-4">
          <a href="#/login" className="bg-[#5C8374] text-white py-2 px-6 rounded-md font-semibold hover:bg-[#4E6C5C] transition-colors">Login</a>
          <a href="#/register" className="border-2 border-[#5C8374] text-[#5C8374] py-2 px-6 rounded-md font-semibold hover:bg-[#5C8374] hover:text-white transition-colors">Register</a>
        </div>
      </div>
    </div>
  );

  const Login = () => {
    const { setCurrentPath } = useContext(RouterContext);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = async (e) => {
      e.preventDefault();
      setIsLoading(true);
      try {
        // FIX: Changed to relative path for Vite proxy to work
        const response = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password }),
        });
        const data = await response.json();

        if (response.ok && data.token) {
          localStorage.setItem('token', data.token);
          localStorage.setItem('userName', data.name);
          setUserData({ email, token: data.token });
          setUserName(data.name);
          setCurrentPath('/dashboard');
        } else {
          showModal(data.message || "Login failed. Please check your credentials.");
        }
      } catch (error) {
        console.error("Login error:", error);
        showModal("An error occurred during login. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    return (
      <div className="min-h-screen bg-[#1A1A1A] text-white flex items-center justify-center flex-col p-4">
        <div className="bg-[#2A2A2A] rounded-xl shadow-lg p-8 max-w-sm w-full mt-8">
          <h2 className="text-2xl font-bold text-center mb-6">Login</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]" required />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]" required />
            <button type="submit" className="w-full bg-[#5C8374] text-white py-3 rounded-md font-semibold hover:bg-[#4E6C5C] transition-colors">Login</button>
          </form>
          <p className="mt-4 text-center text-gray-400">
            <a href="#/forgot-password" className="text-sm text-[#5C8374] hover:underline">Forgot Password?</a>
          </p>
          <p className="mt-4 text-center text-gray-400">
            Don't have an account? <a href="#/register" className="text-[#5C8374] hover:underline">Register here</a>
          </p>
        </div>
      </div>
    );
  };
    const ForgotPassword = () => {
    const { setCurrentPath } = useContext(RouterContext);
    const [email, setEmail] = useState('');

    const handleSubmit = async (e) => {
      e.preventDefault();
      setIsLoading(true);
      try {
        // FIX: Changed to relative path for Vite proxy to work
        const response = await fetch('/api/auth/forgot-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email }),
        });
        const data = await response.json();
        if (response.ok) {
          showModal("A password reset link has been sent to your email.");
          setCurrentPath('/login');
        } else {
          showModal(data.message || "Failed to send reset link.");
        }
      } catch (error) {
        console.error("Forgot password error:", error);
        showModal("An error occurred. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    return (
      <div className="min-h-screen bg-[#1A1A1A] text-white flex items-center justify-center p-4">
        <div className="bg-[#2A2A2A] rounded-xl shadow-lg p-8 max-w-sm w-full">
          <h2 className="text-2xl font-bold text-center mb-6">Forgot Password</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input type="email" placeholder="Enter your email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]" required />
            <button type="submit" className="w-full bg-[#5C8374] text-white py-3 rounded-md font-semibold hover:bg-[#4E6C5C] transition-colors">Send Reset Link</button>
          </form>
           <p className="mt-4 text-center">
            <a href="#/login" className="text-[#5C8374] hover:underline">Back to Login</a>
          </p>
        </div>
      </div>
    );
  };

  const Register = () => {
    const { setCurrentPath } = useContext(RouterContext);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const handleSubmit = async (e) => {
      e.preventDefault();
      if (password !== confirmPassword) {
        showModal("Passwords do not match.");
        return;
      }
      setIsLoading(true);
      try {
        // FIX: Changed to relative path for Vite proxy to work
        const registerResponse = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, password }),
        });
        const registerData = await registerResponse.json();
        if (registerResponse.ok) {
          // FIX: Changed to relative path for Vite proxy to work
          const loginResponse = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
          });
          const loginData = await loginResponse.json();
          if (loginResponse.ok && loginData.token) {
            localStorage.setItem('token', loginData.token);
            localStorage.setItem('userName', loginData.name);
            setUserData({ email, token: loginData.token });
            setUserName(loginData.name);
            setCurrentPath('/dashboard');
          } else {
            showModal(registerData.message || "Registration successful! Please log in.");
            setCurrentPath('/login');
          }
        } else {
          showModal(registerData.message || "Registration failed. Please try again.");
        }
      } catch (error) {
        console.error("Registration/Login error:", error);
        showModal("An error occurred. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    return (
      <div className="min-h-screen bg-[#1A1A1A] text-white flex items-center justify-center flex-col p-4">
        <div className="bg-[#2A2A2A] rounded-xl shadow-lg p-8 max-w-sm w-full mt-8">
          <h2 className="text-2xl font-bold text-center mb-6">Register</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text"
              placeholder="Full Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]"
              required
            />
            <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]" required />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]" required />
            <input type="password" placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]" required />
            <button type="submit" className="w-full bg-[#5C8374] text-white py-3 rounded-md font-semibold hover:bg-[#4E6C5C] transition-colors">Register</button>
          </form>
          <p className="mt-4 text-center text-gray-400">
            Already have an account? <a href="#/login" className="text-[#5C8374] hover:underline">Login here</a>
          </p>
        </div>
      </div>
    );
  };
    
// Helper function to check YouTube video availability and embeddability
const checkYouTubeVideoAvailability = async (videoId) => {
  const oembedUrl = `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`;
  try {
    const response = await fetch(oembedUrl);
    if (response.ok) {
      const data = await response.json();
      // oEmbed response typically contains 'html' field if embeddable
      // We can also check for 'title' and other properties
      if (data && data.html) {
        return { available: true, title: data.title };
      }
    }
    return { available: false };
  } catch (error) {
    console.error("Error checking YouTube video availability:", error);
    return { available: false };
  }
};

// New VideoEmbed component to handle individual video loading and error states
const VideoEmbed = ({ videoId }) => {
  const [status, setStatus] = useState('loading'); // 'loading', 'available', 'unavailable'
  const [videoTitle, setVideoTitle] = useState('');

  useEffect(() => {
    const checkVideo = async () => {
      const result = await checkYouTubeVideoAvailability(videoId);
      if (result.available) {
        setStatus('available');
        setVideoTitle(result.title);
      } else {
        setStatus('unavailable');
      }
    };
    checkVideo();
  }, [videoId]); // Re-run effect if videoId changes

  if (status === 'loading') {
    return (
      <div className="my-4 flex flex-col items-center justify-center h-48 bg-[#2A2A2A] rounded-md text-gray-400 p-4">
        <div className="w-8 h-8 border-4 border-dashed rounded-full animate-spin border-[#5C8374]"></div>
        <p className="mt-2 text-center">Loading video...</p>
      </div>
    );
  } else if (status === 'unavailable') {
    return (
      <div className="my-4 flex flex-col items-center justify-center h-48 bg-[#2A2A2A] rounded-md text-gray-400 p-4">
        <p className="text-lg font-semibold">Video Unavailable 😔</p>
        <p className="text-sm text-center">This video might have been removed, is private, or embedding is disabled.</p>
        <a href={`https://www.youtube.com/watch?v=${videoId}`} target="_blank" rel="noopener noreferrer" className="text-[#5C8374] hover:underline mt-2 text-sm">
          Try watching on YouTube
        </a>
      </div>
    );
  } else { // status === 'available'
    return (
      <div className="my-4 aspect-w-16 aspect-h-9">
        <iframe
          className="w-full h-full rounded-md"
          src={`https://www.youtube.com/embed/${videoId}`}
          title={videoTitle || "YouTube video player"}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen>
        </iframe>
      </div>
    );
  }
};

// New helper function to parse the fitness plan text into an array of React elements
const parseFitnessPlanToReactElements = (planText) => {
  if (!planText) return [];

  const elements = [];
  const lines = planText.split('\n');
  const youtubeRegex = /(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/;

  let currentListItems = [];

  lines.forEach((line, index) => {
    const videoMatch = line.match(youtubeRegex);

    if (videoMatch && videoMatch[1]) {
      // If there's an active list, close it before adding the video
      if (currentListItems.length > 0) {
        elements.push(<ul key={`list-${elements.length}`} className="list-disc list-inside space-y-1 pl-4">{currentListItems}</ul>);
        currentListItems = [];
      }
      const videoId = videoMatch[1];
      elements.push(<VideoEmbed key={`video-${videoId}-${index}`} videoId={videoId} />);
    } else if (line.startsWith('* ')) {
      // This is a list item
      let listItemText = line.substring(2).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      currentListItems.push(<li key={`li-${index}`}>{<span dangerouslySetInnerHTML={{ __html: listItemText }} />}</li>);
    } else {
      // This is a regular text line
      // If there's an active list, close it before adding the text
      if (currentListItems.length > 0) {
        elements.push(<ul key={`list-${elements.length}`} className="list-disc list-inside space-y-1 pl-4">{currentListItems}</ul>);
        currentListItems = [];
      }
      let formattedLine = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      if (formattedLine.trim() !== '') { // Avoid empty paragraphs
        elements.push(<p key={`p-${index}`} className="my-2" dangerouslySetInnerHTML={{ __html: formattedLine }} />);
      }
    }
  });

  // Add any remaining list items
  if (currentListItems.length > 0) {
    elements.push(<ul key={`list-${elements.length}`} className="list-disc list-inside space-y-1 pl-4">{currentListItems}</ul>);
  }

  return elements;
};


  const Dashboard = () => {
    const { setCurrentPath, userName, handleLogout } = useContext(RouterContext);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    
    // New state to hold the parsed React elements for rendering
    const [renderedFitnessPlan, setRenderedFitnessPlan] = useState([]);

    console.log("Dashboard component rendered.");

    const fetchFitnessData = useCallback(async () => {
      console.log("fetchFitnessData called.");
      const token = localStorage.getItem('token');
      
      console.log("Token in localStorage:", token);

      if (!token) {
        console.log("No token found, returning early from fetchFitnessData.");
        return;
      }

      try {
        const response = await fetch('/api/fitness/data', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
        });
        const data = await response.json();
        
        console.log("Fetch response received:", data);

        if (response.ok && data) {
          // Only update state if the new value is different to prevent re-renders
          if (JSON.stringify(fitnessData) !== JSON.stringify(data.fitnessData)) {
            setFitnessData(data.fitnessData);
          }
          if (bmiResult !== data.bmiResult) {
            setBmiResult(data.bmiResult);
          }
          // Set the raw fitnessPlan string, which will trigger the parsing useEffect
          if (fitnessPlan !== data.fitnessPlan) {
            setFitnessPlan(data.fitnessPlan);
          }
        } else if (response.status === 404) {
          // Only update state if the new value is different to prevent re-renders
          if (fitnessData !== null) setFitnessData(null);
          if (bmiResult !== null) setBmiResult(null);
          if (fitnessPlan !== '') setFitnessPlan('');
          console.log("404: No fitness data found for this user.");
        }
      } catch (error) {
        console.error("Fetch fitness data error:", error);
      }
    }, [fitnessData, bmiResult, fitnessPlan]); 

    useEffect(() => {
      console.log("Dashboard useEffect triggered.");
      fetchFitnessData();
    }, [fetchFitnessData]);

    // New useEffect to parse and set the rendered plan when fitnessPlan changes
    useEffect(() => {
        // This function is now synchronous and returns elements directly
        const elements = parseFitnessPlanToReactElements(fitnessPlan);
        setRenderedFitnessPlan(elements);
    }, [fitnessPlan]); // This effect runs whenever fitnessPlan state changes
    
    const handleDeleteAccount = async () => {
        setIsLoading(true);
        const token = localStorage.getItem('token');
        if (!token) {
            handleLogout();
            return;
        }

        try {
            const response = await fetch('/api/auth/delete-account', {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` },
            });

            if (response.ok) {
                handleLogout();
                showModal("Your account has been successfully deleted.");
            } else {
                const data = await response.json();
                showModal(data.message || "Failed to delete account.");
            }
        } catch (error) {
            console.error("Account deletion error:", error);
            showModal("An error occurred during account deletion. Please try again.");
        } finally {
            setIsLoading(false);
            setIsDeleteModalOpen(false);
        }
    };

    return (
      <div className="bg-[#1A1A1A] text-white flex flex-col items-center p-6 min-h-screen">
        <div className="w-full max-w-4xl space-y-6">
          {fitnessPlan ? (
            <>
              <div className="bg-[#2A2A2A] rounded-xl shadow-lg p-6 space-y-4 mt-8">
                <h2 className="text-3xl font-bold text-[#5C8374] border-b border-gray-600 pb-2">{userName}'s Fitness Profile</h2>
                {fitnessData && (
                  <div className="text-lg space-y-2">
                    <p><strong>Height:</strong> {fitnessData.height} cm</p>
                    <p><strong>Weight:</strong> {fitnessData.weight} kg</p>
                    <p><strong>Age:</strong> {fitnessData.age}</p>
                    <p><strong>Gender:</strong> {fitnessData.gender}</p>
                    <p><strong>Workout Habits:</strong> {fitnessData.workoutHabits}</p>
                    <p><strong>BMI:</strong> {bmiResult}</p>
                  </div>
                )}
              </div>
              
              <div className="bg-[#2A2A2A] rounded-xl shadow-lg p-6 space-y-4">
                <h2 className="text-3xl font-bold text-[#5C8374] border-b border-gray-600 pb-2">{userName}'s Fitness Plan</h2>
                <div className="prose prose-invert max-w-none text-gray-300">
                  {/* Render the array of React elements directly */}
                  {renderedFitnessPlan.map((element, index) => (
                    // Ensure each element has a unique key for React to render efficiently
                    React.isValidElement(element) ? React.cloneElement(element, { key: element.key || index }) : element
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="bg-[#2A2A2A] rounded-xl shadow-lg p-10 flex flex-col items-center justify-center space-y-4 mt-8 text-center">
              <h2 className="text-2xl font-semibold">Welcome {userName}!</h2>
              <p className="text-gray-400">You don't have a fitness plan yet. Let's create one.</p>
              <button onClick={() => setCurrentPath('/input')} className="bg-[#5C8374] text-white py-2 px-6 rounded-md font-semibold hover:bg-[#4E6C5C] transition-colors">
                Create My First Plan
              </button>
            </div>
          )}
          <div className="w-full max-w-4xl pt-6">
              <button type="button" onClick={() => setIsDeleteModalOpen(true)} className="w-full text-white py-3 rounded-md font-semibold bg-red-600 hover:bg-red-700 transition-colors">Delete Account</button>
          </div>
        </div>
        {isDeleteModalOpen && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                <div className="bg-[#2A2A2A] text-white rounded-lg shadow-lg p-6 max-w-sm w-full text-center">
                    <p className="text-lg mb-4">Are you sure you want to delete your account? This action cannot be undone.</p>
                    <div className="flex justify-around space-x-4">
                        <button onClick={handleDeleteAccount} className="flex-1 bg-red-600 text-white py-2 rounded-md font-semibold hover:bg-red-700 transition-colors">Confirm Delete</button>
                        <button onClick={() => setIsDeleteModalOpen(false)} className="flex-1 bg-gray-500 text-white py-2 rounded-md font-semibold hover:bg-gray-600 transition-colors">Cancel</button>
                    </div>
                </div>
            </div>
        )}
      </div>
    );
  };
  
  const Profile = () => {
    const { setCurrentPath, userName, setIsLoading, setLoadingMessage } = useContext(RouterContext);
    const [unitSystem, setUnitSystem] = useState('metric');

    const [formState, setFormState] = useState({
        heightCm: '', weightKg: '', heightFeet: '', heightInches: '', weightLbs: '',
        age: '', gender: '', workoutHabits: ''
    });

    useEffect(() => {
        if (!fitnessData) return;
        const { age, gender, workoutHabits } = fitnessData;
        let newFormState = { age, gender, workoutHabits };
        if (unitSystem === 'metric') {
            newFormState = { ...newFormState, heightCm: fitnessData.height, weightKg: fitnessData.weight };
        } else {
            const weightLbs = (fitnessData.weight * 2.20462).toFixed(1);
            const totalInches = fitnessData.height / 2.54;
            const feet = Math.floor(totalInches / 12);
            const inches = (totalInches % 12).toFixed(1);
            newFormState = { ...newFormState, heightFeet: feet, heightInches: inches, weightLbs };
        }
        setFormState(prev => ({...prev, ...newFormState}));
    }, [fitnessData, unitSystem]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormState(prev => ({ ...prev, [name]: value }));
    };

    const handleUpdate = async (e) => {
        e.preventDefault();
        let finalHeightCm, finalWeightKg;
        const { age, gender, workoutHabits } = formState;

        if (unitSystem === 'imperial') {
            const feet = parseFloat(formState.heightFeet);
            const inches = parseFloat(formState.heightInches) || 0;
            const lbs = parseFloat(formState.weightLbs);
            finalHeightCm = (feet * 12 + inches) * 2.54;
            finalWeightKg = lbs / 2.20462;
        } else {
            finalHeightCm = parseFloat(formState.heightCm);
            finalWeightKg = parseFloat(formState.weightKg);
        }
        if (isNaN(finalHeightCm) || isNaN(finalWeightKg) || finalHeightCm <= 0 || finalWeightKg <= 0 || !age || !gender || !workoutHabits) {
            showModal("Please ensure all fields are filled out with valid positive numbers for height and weight.");
            return;
        }
        
        setIsLoading(true);
        setLoadingMessage(`${userName}, your fitness plan is being regenerated. This may take a few moments. Please be patient.`);

        const token = localStorage.getItem('token');
        if (!token) {
            setIsLoading(false);
            setLoadingMessage('');
            return;
        }

        try {
            const heightInMeters = finalHeightCm / 100;
            const bmi = (finalWeightKg / (heightInMeters * heightInMeters)).toFixed(2);
            // UPDATED PROMPT FOR BETTER VIDEO RESULTS
            const planPrompt = `Generate a new customized 30-day fitness plan for a ${age}-year-old ${gender} who now weighs ${finalWeightKg.toFixed(1)} kg and is ${finalHeightCm.toFixed(1)} cm tall. Their updated workout habits are: ${workoutHabits}. Their new BMI is ${bmi}.
            
            Please format the plan with clear, bolded section headers (e.g., **Phase 1: Weeks 1-2**). Use bullet points for lists of exercises and dietary suggestions. For each exercise, please also provide a real, valid YouTube video link on a new line immediately following the exercise.
            
            **Important:** When providing YouTube video links, prioritize videos from reputable fitness channels with high views and positive engagement. Ensure the video links are publicly accessible and can be embedded on a website. Prefer tutorial videos that clearly demonstrate proper form.
            
            Example format:
            * Push-ups
            https://www.youtube.com/watch?v=IODxDxX7oi4
            * Squats
            https://www.youtube.com/watch?v=aclHkVPER9I
            
            Ensure the plan is well-structured and easy to read.`;

            const planResponse = await fetch('http://localhost:5001/api/fitness/generate-fitness-plan', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                body: JSON.stringify({ prompt: planPrompt }),
            });
            const planResult = await planResponse.json();
            if (!planResponse.ok) throw new Error(planResult.message || "Failed to generate new plan.");
            const updatedData = {
                fitnessData: { height: finalHeightCm, weight: finalWeightKg, age, gender, workoutHabits },
                bmiResult: bmi,
                fitnessPlan: planResult.plan,
            };
            // FIX: Changed to relative path for Vite proxy to work
            const updateResponse = await fetch('/api/fitness/data', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                body: JSON.stringify(updatedData),
            });
            const result = await updateResponse.json();
            if (!updateResponse.ok) throw new Error(result.message || "Failed to update profile.");
            setFitnessData(result.fitnessData);
            setBmiResult(result.bmiResult);
            setFitnessPlan(result.fitnessPlan);
            showModal("Profile and plan updated successfully!");
            setCurrentPath('/dashboard');
        } catch (error) {
            showModal(error.toString());
        } finally {
            setIsLoading(false);
            setLoadingMessage('');
        }
    };
    
    return (
        <div className="min-h-screen bg-[#1A1A1A] text-white flex items-center justify-center p-4">
            <div className="bg-[#2A2A2A] rounded-xl shadow-lg p-8 max-w-lg w-full">
                <h2 className="text-2xl font-bold text-[#5C8374] text-center mb-6">{userName}'s Profile</h2>
                 <div className="flex justify-center items-center mb-4 bg-[#1A1A1A] rounded-lg p-1">
                    <button onClick={() => setUnitSystem('metric')} className={`w-1/2 py-2 rounded-md transition-colors ${unitSystem === 'metric' ? 'bg-[#5C8374]' : ''}`}>Metric</button>
                    <button onClick={() => setUnitSystem('imperial')} className={`w-1/2 py-2 rounded-md transition-colors ${unitSystem === 'imperial' ? 'bg-[#5C8374]' : ''}`}>Imperial</button>
                </div>
                <form onSubmit={handleUpdate} className="space-y-4">
                    {unitSystem === 'metric' ? (
                        <>
                            <input type="number" name="heightCm" placeholder="Height (cm)" value={formState.heightCm || ''} onChange={handleChange} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600" required />
                            <input type="number" name="weightKg" placeholder="Weight (kg)" value={formState.weightKg || ''} onChange={handleChange} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600" required />
                        </>
                    ) : (
                        <div className="grid grid-cols-2 gap-2">
                             <input type="number" name="heightFeet" placeholder="Height (ft)" value={formState.heightFeet || ''} onChange={handleChange} className="p-3 rounded-md bg-[#1A1A1A] border border-gray-600" required />
                             <input type="number" name="heightInches" placeholder="(in)" value={formState.heightInches || ''} onChange={handleChange} className="p-3 rounded-md bg-[#1A1A1A] border border-gray-600" />
                             <input type="number" name="weightLbs" placeholder="Weight (lbs)" value={formState.weightLbs || ''} onChange={handleChange} className="col-span-2 p-3 rounded-md bg-[#1A1A1A] border border-gray-600" required />
                        </div>
                    )}
                    <input type="number" name="age" placeholder="Age" value={formState.age || ''} onChange={handleChange} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600" required />
                    <select name="gender" value={formState.gender || ''} onChange={handleChange} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600" required>
                        <option value="">Select Gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                    <textarea name="workoutHabits" placeholder="Workout Habits" value={formState.workoutHabits || ''} onChange={handleChange} rows="3" className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600"></textarea>
                    <button type="submit" className="w-full bg-[#5C8374] text-white py-3 rounded-md font-semibold hover:bg-[#4E6C5C]">Update and Regenerate Plan</button>
                </form>
            </div>
        </div>
    );
  };

  const FitnessInput = () => {
    const { setCurrentPath, userName, setIsLoading, setLoadingMessage } = useContext(RouterContext);
    const [unitSystem, setUnitSystem] = useState('metric');
    
    // Metric states
    const [heightCm, setHeightCm] = useState('');
    const [weightKg, setWeightKg] = useState('');

    // Imperial states
    const [heightFeet, setHeightFeet] = useState('');
    const [heightInches, setHeightInches] = useState('');
    const [weightLbs, setWeightLbs] = useState('');

    // Shared states
    const [workoutHabits, setWorkoutHabits] = useState('');
    const [age, setAge] = useState('');
    const [gender, setGender] = useState('');

    const handleSubmit = async (e) => {
      e.preventDefault();
      
      let finalHeightCm, finalWeightKg;

      if (unitSystem === 'imperial') {
        const feet = parseFloat(heightFeet);
        const inches = parseFloat(heightInches) || 0;
        const lbs = parseFloat(weightLbs);
        if (isNaN(feet) || isNaN(lbs) || feet <= 0 || lbs <= 0) {
            showModal("Please enter valid positive numbers for feet and weight.");
            return;
        }
        finalHeightCm = (feet * 12 + inches) * 2.54;
        finalWeightKg = lbs / 2.20462;
      } else {
        const cm = parseFloat(heightCm);
        const kg = parseFloat(weightKg);
        if (isNaN(cm) || isNaN(kg) || cm <= 0 || kg <= 0) {
            showModal("Please enter valid positive numbers for height and weight.");
            return;
        }
        finalHeightCm = cm;
        finalWeightKg = kg;
      }
      if (isNaN(finalHeightCm) || isNaN(finalWeightKg) || finalHeightCm <= 0 || finalWeightKg <= 0 || !age || !gender || !workoutHabits) {
          showModal("Please ensure all fields are filled out with valid positive numbers for height and weight.");
          return;
      }

      const heightInMeters = finalHeightCm / 100;
      const bmi = (finalWeightKg / (heightInMeters * heightInMeters)).toFixed(2);
      
      setIsLoading(true);
      setLoadingMessage(`${userName}, your fitness plan is being generated. This may take a few moments. Please be patient.`);

      const token = localStorage.getItem('token');
      if (!token) {
        showModal("You must be logged in to save data.");
        setIsLoading(false);
        setLoadingMessage('');
        return;
      }
      // UPDATED PROMPT FOR BETTER VIDEO RESULTS
      const planPrompt = `Generate a customized 30-day fitness plan for a ${age}-year-old ${gender} who weighs ${finalWeightKg.toFixed(2)} kg and is ${finalHeightCm.toFixed(2)} cm tall. Their current workout habits are: ${workoutHabits}. The BMI is ${bmi}.
      
      Please format the plan with clear, bolded section headers (e.g., **Phase 1: Weeks 1-2**). Use bullet points for lists of exercises and dietary suggestions, starting each with a "*". For each exercise, please also provide a real, valid YouTube video link on a new line immediately following the exercise.
      
      **Important:** When providing YouTube video links, prioritize videos from reputable fitness channels with high views and positive engagement. Ensure the video links are publicly accessible and can be embedded on a website. Prefer tutorial videos that clearly demonstrate proper form.
      
      Example format:
      * Push-ups
      https://www.youtube.com/watch?v=IODxDxX7oi4
      * Squats
      https://www.youtube.com/watch?v=aclHkVPER9I
      
      Ensure the plan is well-structured and easy to read.`;

      const dataToSave = {
        fitnessData: { height: finalHeightCm, weight: finalWeightKg, workoutHabits, age, gender },
        bmiResult: bmi,
      };

      try {
        const planResponse = await fetch('http://localhost:5001/api/fitness/generate-fitness-plan', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
          body: JSON.stringify({ prompt: planPrompt }),
        });
        const planResult = await planResponse.json();

        if (!planResponse.ok) throw new Error(planResult.message || "Failed to generate fitness plan.");
        const generatedPlan = planResult.plan;
        
        // FIX: Changed to relative path for Vite proxy to work
        const updateResponse = await fetch('/api/fitness/data', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
          body: JSON.stringify({ ...dataToSave, fitnessPlan: generatedPlan }),
        });
        const updatedData = await updateResponse.json();

        if (updateResponse.ok) {
          setFitnessData(updatedData.fitnessData);
          setBmiResult(updatedData.bmiResult);
          setFitnessPlan(generatedPlan); // Use the plan we received
          setCurrentPath('/dashboard');
        } else {
          throw new Error(updatedData.message || "Failed to save fitness plan.");
        }
      } catch (error) {
        console.error("Error handling fitness data:", error);
        showModal(error.message || "An unexpected error occurred.");
      } finally {
        setIsLoading(false);
        setLoadingMessage('');
      }
    };

    return (
      <div className="min-h-screen bg-[#1A1A1A] text-white flex items-center justify-center p-4">
        <div className="bg-[#2A2A2A] rounded-xl shadow-lg p-8 max-w-lg w-full">
          <h2 className="text-2xl font-bold text-center mb-6">Create Your Plan</h2>
          <div className="flex justify-center items-center mb-4 bg-[#1A1A1A] rounded-lg p-1">
            <button onClick={() => setUnitSystem('metric')} className={`w-1/2 py-2 rounded-md transition-colors ${unitSystem === 'metric' ? 'bg-[#5C8374]' : ''}`}>Metric</button>
            <button onClick={() => setUnitSystem('imperial')} className={`w-1/2 py-2 rounded-md transition-colors ${unitSystem === 'imperial' ? 'bg-[#5C8374]' : ''}`}>Imperial</button>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            {unitSystem === 'metric' ? (
              <>
                <input type="number" placeholder="Height (cm)" value={heightCm} onChange={(e) => setHeightCm(e.target.value)} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]" required />
                <input type="number" placeholder="Weight (kg)" value={weightKg} onChange={(e) => setWeightKg(e.target.value)} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]" required />
              </>
            ) : (
                <div className="grid grid-cols-2 gap-2">
                    <input type="number" placeholder="Height (ft)" value={heightFeet} onChange={(e) => setHeightFeet(e.target.value)} className="p-3 rounded-md bg-[#1A1A1A] border border-gray-600" required />
                    <input type="number" placeholder="(in)" value={heightInches} onChange={(e) => setHeightInches(e.target.value)} className="p-3 rounded-md bg-[#1A1A1A] border border-gray-600" />
                    <input type="number" placeholder="Weight (lbs)" value={weightLbs} onChange={(e) => setWeightLbs(e.target.value)} className="col-span-2 p-3 rounded-md bg-[#1A1A1A] border border-gray-600" required />
                </div>
            )}
            <input type="number" placeholder="Age" value={age} onChange={(e) => setAge(e.target.value)} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]" required />
            <select value={gender} onChange={(e) => setGender(e.target.value)} className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]" required>
              <option value="">Select Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
            <textarea placeholder="Describe your current workout habits..." value={workoutHabits} onChange={(e) => setWorkoutHabits(e.target.value)} rows="3" className="w-full p-3 rounded-md bg-[#1A1A1A] border border-gray-600 focus:outline-none focus:ring-2 focus:ring-[#5C8374]" required></textarea>
            <button type="submit" className="w-full bg-[#5C8374] text-white py-3 rounded-md font-semibold hover:bg-[#4E6C5C] transition-colors">Save & Get Plan</button>
          </form>
        </div>
      </div>
    );
  };

  const renderComponent = () => {
    const isAuthenticated = !!userData;
    
    switch (currentPath) {
      case '/':
        return isAuthenticated ? <Dashboard /> : <Home />;
      case '/login':
        return <Login />;
      case '/register':
        return <Register />;
       case '/forgot-password':
        return <ForgotPassword />;
       case '/profile':
        return isAuthenticated ? <Profile /> : <Home />;
      case '/dashboard':
        return isAuthenticated ? <Dashboard /> : <Home />;
      case '/input':
        return isAuthenticated ? <FitnessInput /> : <Home />;
      default:
        return isAuthenticated ? <Dashboard /> : <Home />;
    }
  };

  const isAuthPage = ['/', '/login', '/register', '/forgot-password'].includes(currentPath);

  return (
    <RouterContext.Provider value={{ setCurrentPath, handleLogout, userName, setIsLoading, setLoadingMessage }}>
      <div className="font-inter bg-[#1A1A1A]">
        {isAuthPage ? <AuthNavbar /> : <Navbar />}
        {renderComponent()}
        {isModalOpen && <CustomModal message={modalMessage} onClose={() => setIsModalOpen(false)} />}
        {isLoading && <LoadingOverlay message={loadingMessage} />}
      </div>
    </RouterContext.Provider>
  );
};

export default App;
