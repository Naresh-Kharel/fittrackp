// =========================================================================
//  FITTRACK BACKEND SERVER
//  This server handles user authentication, data storage, and calls the
//  Gemini API securely without exposing the key to the frontend.
// =========================================================================

// Import necessary modules using ES Module syntax
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import mongoose from 'mongoose';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import fetch from 'node-fetch';
import helmet from 'helmet';
import dotenv from 'dotenv';

// Load environment variables from .env file
dotenv.config();

// Initialize the Express app
const app = express();
const PORT = 5001;

// MongoDB connection URI from .env file
const MONGODB_URI = process.env.MONGODB_URI;
const JWT_SECRET = process.env.JWT_SECRET;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

// Ensure all required environment variables are set
if (!MONGODB_URI || !JWT_SECRET || !GEMINI_API_KEY) {
  console.error("Error: Missing required environment variables. Please check your .env file.");
  process.exit(1);
}

// =========================================================================
//  Middleware and Database Connection
// =========================================================================
// Use middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.json());

// Add the Helmet middleware with a custom Content Security Policy
// THIS HAS BEEN CORRECTED TO ALLOW YOUTUBE EMBEDS
app.use(helmet.contentSecurityPolicy({
  directives: {
    ...helmet.contentSecurityPolicy.getDefaultDirectives(),
    "frame-src": ["'self'", "https://www.youtube.com"], // Corrected Policy
  },
}));

// Connect to MongoDB
mongoose.connect(MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Could not connect to MongoDB:', err));

// =========================================================================
//  Database Schema and Model
// =========================================================================
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: { type: String },
  fitnessData: {
    height: { type: Number },
    weight: { type: Number },
    age: { type: Number },
    gender: { type: String },
    workoutHabits: { type: String },
  },
  bmiResult: { type: String },
  fitnessPlan: { type: String },
});
const User = mongoose.model('User', userSchema);

// =========================================================================
//  Authentication Middleware
// =========================================================================
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (token == null) {
    return res.status(401).json({ message: 'Authentication token missing.' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token.' });
    }
    req.user = user;
    next();
  });
};

// =========================================================================
//  API Routes
// =========================================================================

// Route to register a new user
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(409).json({ message: 'User with this email already exists.' });
    }
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    const newUser = new User({ email, password: hashedPassword, name });
    await newUser.save();
    res.status(201).json({ message: 'User registered successfully.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error registering user.' });
  }
});

// Route to log in a user and generate a token
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials.' });
    }
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials.' });
    }
    const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: '1h' });
    res.json({ message: 'Login successful.', token, name: user.name });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error logging in.' });
  }
});

// Route to get a user's fitness data
app.get('/api/fitness/data', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }
    if (user.fitnessData && user.fitnessPlan) {
      res.status(200).json({
        name: user.name,
        fitnessData: user.fitnessData,
        bmiResult: user.bmiResult,
        fitnessPlan: user.fitnessPlan
      });
    } else {
      res.status(404).json({ message: 'No fitness data found for this user.' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching fitness data.' });
  }
});

// Route to save/update a user's initial fitness data
app.post('/api/fitness/data', authenticateToken, async (req, res) => {
  try {
    const { fitnessData, bmiResult, fitnessPlan } = req.body;
    const updatedUser = await User.findByIdAndUpdate(
      req.user.userId,
      { $set: { fitnessData, bmiResult, fitnessPlan } },
      { new: true, runValidators: true, upsert: true }
    );
    res.status(200).json({
      message: 'Fitness data saved successfully.',
      fitnessData: updatedUser.fitnessData,
      bmiResult: updatedUser.bmiResult
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error saving fitness data.' });
  }
});

// Route to update the fitness data with the generated plan
app.put('/api/fitness/data', authenticateToken, async (req, res) => {
  try {
    const { fitnessData, bmiResult, fitnessPlan } = req.body;
    const updatedUser = await User.findByIdAndUpdate(
      req.user.userId,
      { $set: { fitnessData, bmiResult, fitnessPlan } },
      { new: true, runValidators: true, upsert: true }
    );
    res.status(200).json({
      message: 'Fitness plan updated successfully.',
      fitnessData: updatedUser.fitnessData,
      bmiResult: updatedUser.bmiResult,
      fitnessPlan: updatedUser.fitnessPlan
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating fitness plan.' });
  }
});

// Route to delete a user account
app.delete('/api/auth/delete-account', authenticateToken, async (req, res) => {
    try {
        const deletedUser = await User.findByIdAndDelete(req.user.userId);
        if (!deletedUser) {
            return res.status(404).json({ message: 'User not found.' });
        }
        res.status(200).json({ message: 'Account deleted successfully.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting account.' });
    }
});

// Route to handle password reset
app.post('/api/auth/forgot-password', async (req, res) => {
    try {
        const { email } = req.body;
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'No user found with that email.' });
        }
        // In a real application, you would generate a password reset token and email it to the user.
        console.log(`Password reset requested for ${email}. (In a real app, an email would be sent.)`);
        res.status(200).json({ message: 'Password reset link sent to email.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error processing request.' });
    }
});

// Route to generate a fitness plan using the Gemini API
app.post('/api/fitness/generate-fitness-plan', authenticateToken, async (req, res) => {
  const { prompt } = req.body;
  try {
    const chatHistory = [];
    chatHistory.push({ role: "user", parts: [{ text: prompt }] });
    const payload = { contents: chatHistory };
    const apiKey = GEMINI_API_KEY;
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key=${apiKey}`;
    let response = null;
    let result = null;
    let retryCount = 0;
    const maxRetries = 5;
    const initialDelay = 1000;
    while (retryCount < maxRetries) {
      try {
        response = await fetch(apiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        if (response.status === 429) {
          const delay = initialDelay * Math.pow(2, retryCount);
          console.warn(`Rate limit exceeded. Retrying in ${delay}ms...`);
          await new Promise(resolve => setTimeout(resolve, delay));
          retryCount++;
          continue;
        }
        if (!response.ok) {
          throw new Error(`API call failed with status: ${response.status}`);
        }
        result = await response.json();
        break;
      } catch (error) {
        console.error('API fetch error:', error);
        res.status(500).json({ message: 'Failed to communicate with Gemini API.' });
        return;
      }
    }
    if (!result || !result.candidates || result.candidates.length === 0 || !result.candidates[0].content || !result.candidates[0].content.parts || result.candidates[0].content.parts.length === 0) {
        throw new Error('Unexpected API response structure.');
    }
    const generatedPlan = result.candidates[0].content.parts[0].text;
    res.status(200).json({ plan: generatedPlan });
  } catch (error) {
    console.error('Gemini API call error:', error);
    res.status(500).json({ message: 'Failed to generate fitness plan.' });
  }
});

// =========================================================================
//  Server Startup
// =========================================================================
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});