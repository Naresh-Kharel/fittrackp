import express from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import User from '../models/User.js'; // Assuming you have a User model file
import dotenv from 'dotenv';

dotenv.config();

// The auth router now needs to be a function that accepts the JWT_SECRET
const createAuthRouter = (jwtSecret) => {
    const router = express.Router();

    // User Registration
    router.post('/register', async (req, res) => {
        const { name, email, password } = req.body;
        try {
            // Check if user already exists
            let user = await User.findOne({ email });
            if (user) {
                return res.status(400).json({ message: 'User already exists' });
            }

            // Hash password
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(password, salt);

            // Create new user
            user = new User({ name, email, password: hashedPassword });
            await user.save();

            // Generate JWT token
            const payload = { user: { id: user.id } };
            const token = jwt.sign(payload, jwtSecret, { expiresIn: '1h' });

            res.status(201).json({ token, name: user.name, message: 'Registration successful' });
        } catch (error) {
            console.error(error.message);
            res.status(500).send('Server Error');
        }
    });

    // User Login
    router.post('/login', async (req, res) => {
        const { email, password } = req.body;
        try {
            // Check if user exists
            let user = await User.findOne({ email });
            if (!user) {
                return res.status(400).json({ message: 'Invalid credentials' });
            }

            // Compare passwords
            const isMatch = await bcrypt.compare(password, user.password);
            if (!isMatch) {
                return res.status(400).json({ message: 'Invalid credentials' });
            }

            // Generate JWT token
            const payload = { user: { id: user.id } };
            const token = jwt.sign(payload, jwtSecret, { expiresIn: '1h' });

            res.json({ token, name: user.name });
        } catch (error) {
            console.error(error.message);
            res.status(500).send('Server Error');
        }
    });

    // Forgot Password (Placeholder)
    router.post('/forgot-password', (req, res) => {
        // Implement password reset logic here
        res.json({ message: "Password reset functionality is not yet implemented." });
    });
    
    // Delete Account Route
    router.delete('/delete-account', (req, res) => {
        // Placeholder for account deletion logic
        res.status(501).json({ message: 'Account deletion functionality is not yet implemented.' });
    });

    return router;
};

export default createAuthRouter;