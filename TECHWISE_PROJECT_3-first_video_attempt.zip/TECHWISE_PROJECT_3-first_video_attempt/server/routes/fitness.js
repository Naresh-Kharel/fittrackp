import express from 'express';
import jwt from 'jsonwebtoken';
import { MongoClient } from 'mongodb';
import { GoogleGenerativeAI } from '@google/generative-ai';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';

dotenv.config();

const router = express.Router();
const uri = process.env.MONGODB_URI;
const client = new MongoClient(uri);
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401);

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    standardHeaders: true,
    legacyHeaders: false,
});

async function connectToMongo() {
    await client.connect();
    return client.db('fittrack');
}

router.post('/generate-fitness-plan', authenticateToken, apiLimiter, async (req, res) => {
    try {
        const { prompt } = req.body;
        if (!prompt || prompt.length < 50) {
            return res.status(400).json({ message: "Prompt is too short or missing." });
        }
        
        // --- FIX IS HERE ---
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        
        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();
        res.json({ plan: text });
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        res.status(500).json({ message: "Failed to communicate with Gemini API." });
    }
});

router.get('/data', authenticateToken, async (req, res) => {
    try {
        const db = await connectToMongo();
        const userFitnessData = await db.collection('fitness').findOne({ userId: req.user.id });
        if (!userFitnessData) {
            return res.status(404).json({ message: "No fitness data found for this user." });
        }
        res.json(userFitnessData);
    } catch (error) {
        console.error("Error fetching fitness data:", error);
        res.status(500).json({ message: "Error fetching fitness data." });
    }
});

router.post('/data', authenticateToken, async (req, res) => {
    try {
        const db = await connectToMongo();
        const { fitnessData, bmiResult, fitnessPlan } = req.body;
        if (!fitnessData || !bmiResult || !fitnessPlan) {
            return res.status(400).json({ message: "Missing required fields." });
        }
        await db.collection('fitness').updateOne(
            { userId: req.user.id },
            { $set: { userId: req.user.id, fitnessData, bmiResult, fitnessPlan } },
            { upsert: true }
        );
        const updatedData = await db.collection('fitness').findOne({ userId: req.user.id });
        res.json(updatedData);
    } catch (error) {
        console.error("Error saving fitness data:", error);
        res.status(500).json({ message: "Error saving fitness data." });
    }
});

router.put('/data', authenticateToken, async (req, res) => {
    try {
        const db = await connectToMongo();
        const { fitnessData, bmiResult, fitnessPlan } = req.body;
        if (!fitnessData || !bmiResult || !fitnessPlan) {
            return res.status(400).json({ message: "Missing required fields." });
        }
        const result = await db.collection('fitness').updateOne(
            { userId: req.user.id },
            { $set: { userId: req.user.id, fitnessData, bmiResult, fitnessPlan } },
            { upsert: true }
        );
        if (result.matchedCount === 0 && result.upsertedCount === 0) {
            return res.status(404).json({ message: "User data not found for update." });
        }
        const updatedData = await db.collection('fitness').findOne({ userId: req.user.id });
        res.json(updatedData);
    } catch (error) {
        console.error("Error updating fitness data:", error);
        res.status(500).json({ message: "Error updating fitness data." });
    }
});

export default router;