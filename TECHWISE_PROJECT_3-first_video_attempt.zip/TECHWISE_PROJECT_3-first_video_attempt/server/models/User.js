import mongoose from 'mongoose';

// User Schema
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: { type: String },
  fitnessData: {
    height: { type: Number },
    weight: { type: Number },
    age: { type: Number },
    gender: { type: String },
    workoutHabits: { type: String },
  },
  bmiResult: { type: String },
  fitnessPlan: { type: String },
});

// User Model
const User = mongoose.model('User', userSchema);
export default User;
